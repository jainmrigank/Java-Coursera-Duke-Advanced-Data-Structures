/**
 * @author UCSD MOOC development team and YOU
 * 
 * A class which reprsents a graph of geographic locations
 * Nodes in the graph are intersections between 
 *
 */
package roadgraph;


import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Set;
import java.util.function.Consumer;

import geography.GeographicPoint;
import util.GraphLoader;

/**
 * @author UCSD MOOC development team and YOU
 * 
 * A class which represents a graph of geographic locations
 * Nodes in the graph are intersections between 
 *
 */
public class MapGraph{
	//TODO: Add your member variables here in WEEK 3
	private HashMap<GeographicPoint,MapNode> vertices;
	private int numVertices;
	private int numEdges; 
	
	/** 
	 * Create a new empty MapGraph 
	 */
	public MapGraph()
	{
		// TODO: Implement in this constructor in WEEK 3
		this.vertices=new HashMap<GeographicPoint,MapNode>();
		this.numVertices=0;
		this.numEdges=0;
	}
	
	/**
	 * Get the number of vertices (road intersections) in the graph
	 * @return The number of vertices in the graph.
	 */
	public int getNumVertices()
	{
		//TODO: Implement this method in WEEK 3
		return this.numVertices;
	}
	/**
	 * Return the intersections, which are the vertices in this graph.
	 * @return The vertices in this graph as GeographicPoints
	 */
	public Set<GeographicPoint> getVertices()
	{
		//TODO: Implement this method in WEEK 3
		Set<GeographicPoint> ans=new HashSet<GeographicPoint>();
		for(GeographicPoint i:vertices.keySet())
		{
			if(vertices.get(i)!=null)
			ans.add(i);
		}
		return ans;
	}
	
	/**
	 * Get the number of road segments in the graph
	 * @return The number of edges in the graph.
	 */
	public int getNumEdges()
	{
		//TODO: Implement this method in WEEK 3
		return this.numEdges;
	}

	
	
	/** Add a node corresponding to an intersection at a Geographic Point
	 * If the location is already in the graph or null, this method does 
	 * not change the graph.
	 * @param location  The location of the intersection
	 * @return true if a node was added, false if it was not (the node
	 * was already in the graph, or the parameter is null).
	 */
	public boolean addVertex(GeographicPoint location)
	{
		if(location==null)
			return false;
		// TODO: Implement this method in WEEK 3
		if(!vertices.containsKey(location))
			{
				vertices.put(location,new MapNode(location));
				this.numVertices+=1;
				return true;
			}
		return false;
	}
	
	/**
	 * Adds a directed edge to the graph from pt1 to pt2.  
	 * Precondition: Both GeographicPoints have already been added to the graph
	 * @param from The starting point of the edge
	 * @param to The ending point of the edge
	 * @param roadName The name of the road
	 * @param roadType The type of the road
	 * @param length The length of the road, in km
	 * @throws IllegalArgumentException If the points have not already been
	 *   added as nodes to the graph, if any of the arguments is null,
	 *   or if the length is less than 0.
	 */
	public void addEdge(GeographicPoint from, GeographicPoint to, String roadName,
			String roadType, double length) throws IllegalArgumentException {

		//TODO: Implement this method in WEEK 3
		try {
			if(from==null||to==null)
				throw new IllegalArgumentException();
			vertices.get(from).addEdge(from,to,roadName,roadType,length);
			this.numEdges+=1;
		}
		catch(IllegalArgumentException e)
		{
			System.out.println(e);
		}
		
	}
	

	/** Find the path from start to goal using breadth first search
	 * 
	 * @param start The starting location
	 * @param goal The goal location
	 * @return The list of intersections that form the shortest (unweighted)
	 *   path from start to goal (including both start and goal).
	 */
	public List<GeographicPoint> bfs(GeographicPoint start, GeographicPoint goal) {
		// Dummy variable for calling the search algorithms
        Consumer<GeographicPoint> temp = (x) -> {};
        return bfs(start, goal, temp);
	}
	
	/** Find the path from start to goal using breadth first search
	 * 
	 * @param start The starting location
	 * @param goal The goal location
	 * @param nodeSearched A hook for visualization.  See assignment instructions for how to use it.
	 * @return The list of intersections that form the shortest (unweighted)
	 *   path from start to goal (including both start and goal).
	 */
	public List<GeographicPoint> bfs(GeographicPoint start, 
			 					     GeographicPoint goal, Consumer<GeographicPoint> nodeSearched)
	{
		boolean bfsSuccess=false;
		if(start==null||goal==null)
			return null;
		// TODO: Implement this method in WEEK 3
		Queue<GeographicPoint> q=new LinkedList<GeographicPoint>();
		HashSet<GeographicPoint> visited=new HashSet<GeographicPoint>();
		HashMap<GeographicPoint,GeographicPoint> parentMap=new HashMap<GeographicPoint,GeographicPoint>();
		List<GeographicPoint> path=new LinkedList<GeographicPoint>();
		
		q.add(start);
		visited.add(start);
		while(!q.isEmpty())
		{
			GeographicPoint curr=q.remove();
		//	System.out.println(curr);
			nodeSearched.accept(curr);
			if(curr.equals(goal))
				{
					bfsSuccess=true;
					break;
				}
			
			MapNode node=vertices.get(curr);
			for(Edge e:node.getEdges())
			{
				GeographicPoint n=e.getEnd();
				if(!visited.contains(n))
				{
					visited.add(n);
					parentMap.put(n,curr);
					q.add(n);
				}
			}
		}
		//System.out.println(parentMap);
		if(bfsSuccess)
		{
			path.add(goal);
			GeographicPoint parent=parentMap.get(goal);			
			path.add(parent);
			while(parentMap.containsKey(parent))
			{
				parent=parentMap.get(parent);
				path.add(parent);
			}
			Collections.reverse(path);
			return path;
		}
		
		// Hook for visualization.  See writeup.
		//nodeSearched.accept(next.getLocation());
	//	System.out.println(bfsSuccess);
		//System.out.println(path);
		
		return null;
	}
	
	
	

	/** Find the path from start to goal using Dijkstra's algorithm
	 * 
	 * @param start The starting location
	 * @param goal The goal location
	 * @return The list of intersections that form the shortest path from 
	 *   start to goal (including both start and goal).
	 */
	public List<GeographicPoint> dijkstra(GeographicPoint start, GeographicPoint goal) {
		// Dummy variable for calling the search algorithms
		// You do not need to change this method.
        Consumer<GeographicPoint> temp = (x) -> {};
        return dijkstra(start, goal, temp);
	}
	
	/** Find the path from start to goal using Dijkstra's algorithm
	 * 
	 * @param start The starting location
	 * @param goal The goal location
	 * @param nodeSearched A hook for visualization.  See assignment instructions for how to use it.
	 * @return The list of intersections that form the shortest path from 
	 *   start to goal (including both start and goal).
	 */
	public List<GeographicPoint> dijkstra(GeographicPoint start, 
										  GeographicPoint goal, Consumer<GeographicPoint> nodeSearched)
	{
		// TODO: Implement this method in WEEK 4
		
		boolean aSuccess=false;
		if(start==null||goal==null)
			return null;
		// TODO: Implement this method in WEEK 3
		PriorityQueue<MapNode> q=new PriorityQueue<MapNode>();
		HashSet<MapNode> visited=new HashSet<MapNode>();
		HashMap<MapNode,MapNode> parentMap=new HashMap<MapNode,MapNode>();
		
		
		MapNode s=vertices.get(start);
		MapNode g=vertices.get(goal);
		q.add(s);
		visited.add(s);
		while(!q.isEmpty())
		{
			MapNode curr=q.remove();
			curr.setActualDistance(curr.getDistance());
			//	System.out.println(curr);
			nodeSearched.accept(curr.getLocation());
			if(curr.equals(g))
			{
				aSuccess=true;
				break;
			}
			//double distance=curr.getDistance();
			//MapNode node=vertices.get(curr);
			for(Edge e:curr.getEdges())
			{
				//GeographicPoint n1=e.getEnd();
				
				MapNode n=vertices.get(e.getEnd());
				n.setActualDistance(n.getDistance());
				if(!visited.contains(n))
				{
					visited.add(n);
					parentMap.put(n,curr);
					q.add(n);
				}
			}
		}
		//System.out.println(parentMap);
		// Hook for visualization.  See writeup.
		//nodeSearched.accept(next.getLocation());
		//	System.out.println(bfsSuccess);
		//System.out.println(path);
		
		return constructPath(aSuccess,goal,parentMap);

		// Hook for visualization.  See writeup.
		//nodeSearched.accept(next.getLocation());
	
		
	}
	

	
	public List<GeographicPoint> constructPath(boolean res,GeographicPoint goal,HashMap<MapNode,MapNode> parentMap)
	{
		MapNode g=vertices.get(goal);
		List<GeographicPoint> path=new LinkedList<GeographicPoint>();
		path.add(goal);
		GeographicPoint parent=parentMap.get(g).getLocation();			
		path.add(parent);
		while(parentMap.containsKey(vertices.get(parent)))
		{
			parent=parentMap.get(vertices.get(parent)).getLocation();
			path.add(parent);
		}
		Collections.reverse(path);
		return path;
	}

	/** Find the path from start to goal using A-Star search
	 * 
	 * @param start The starting location
	 * @param goal The goal location
	 * @return The list of intersections that form the shortest path from 
	 *   start to goal (including both start and goal).
	 */
	public List<GeographicPoint> aStarSearch(GeographicPoint start, GeographicPoint goal) {
		// Dummy variable for calling the search algorithms
        Consumer<GeographicPoint> temp = (x) -> {};
        return aStarSearch(start, goal, temp);
	}
	
	/** Find the path from start to goal using A-Star search
	 * 
	 * @param start The starting location
	 * @param goal The goal location
	 * @param nodeSearched A hook for visualization.  See assignment instructions for how to use it.
	 * @return The list of intersections that form the shortest path from 
	 *   start to goal (including both start and goal).
	 */
	public List<GeographicPoint> aStarSearch(GeographicPoint start, 
											 GeographicPoint goal, Consumer<GeographicPoint> nodeSearched)
	{
		// TODO: Implement this method in WEEK 4
		boolean aSuccess=false;
		if(start==null||goal==null)
			return null;
		// TODO: Implement this method in WEEK 3
		PriorityQueue<MapNode> q=new PriorityQueue<MapNode>();
		HashSet<MapNode> visited=new HashSet<MapNode>();
		HashMap<MapNode,MapNode> parentMap=new HashMap<MapNode,MapNode>();
		List<GeographicPoint> path=new LinkedList<GeographicPoint>();
		
		MapNode s=vertices.get(start);
		MapNode g=vertices.get(goal);
		q.add(s);
		visited.add(s);
		while(!q.isEmpty())
		{
			MapNode curr=q.remove();
			//	System.out.println(curr);
			nodeSearched.accept(curr.getLocation());
			if(curr.equals(g))
			{
				aSuccess=true;
				break;
			}
			//double distance=curr.getDistance();
			//MapNode node=vertices.get(curr);
			for(Edge e:curr.getEdges())
			{
				//GeographicPoint n1=e.getEnd();
				
				MapNode n=vertices.get(e.getEnd());
				n.setActualDistance(e.getDistance()+n.getLocation().distance(goal));
				if(!visited.contains(n))
				{
					visited.add(n);
					parentMap.put(n,curr);
					q.add(n);
				}
			}
		}
		//System.out.println(parentMap);
		// Hook for visualization.  See writeup.
		//nodeSearched.accept(next.getLocation());
		//	System.out.println(bfsSuccess);
		//System.out.println(path);
		
		return constructPath(aSuccess,goal,parentMap);

		// Hook for visualization.  See writeup.
		//nodeSearched.accept(next.getLocation());
	}
	
	public void printGraph()
	{
		List<GeographicPoint>adjList;
		for(MapNode node:this.vertices.values())
		{
			adjList=new LinkedList<GeographicPoint>();
			adjList.add(node.getLocation());
			
			for(Edge e:node.getEdges())
			{
				adjList.add(e.getEnd());
			}
			System.out.println("Node:"+adjList.get(0));
			System.out.println("Neighbours:");
			for(int i=1;i<adjList.size();i++)
			{
				System.out.println(adjList.get(i));
			}
		}
	}

	
	
	public static void main(String[] args)
	{
		System.out.print("Making a new map...");
		MapGraph firstMap = new MapGraph();
		System.out.print("DONE. \nLoading the map...");
		GraphLoader.loadRoadMap("data/testdata/simpletest.map", firstMap);
		System.out.println("DONE.");
		firstMap.printGraph();
		// You can use this method for testing.  
		
		
		/* Here are some test cases you should try before you attempt 
		 * the Week 3 End of Week Quiz, EVEN IF you score 100% on the 
		 * programming assignment.
		 */
		/*
		MapGraph simpleTestMap = new MapGraph();
		GraphLoader.loadRoadMap("data/testdata/simpletest.map", simpleTestMap);
		
		GeographicPoint testStart = new GeographicPoint(1.0, 1.0);
		GeographicPoint testEnd = new GeographicPoint(8.0, -1.0);
		
		System.out.println("Test 1 using simpletest: Dijkstra should be 9 and AStar should be 5");
		List<GeographicPoint> testroute = simpleTestMap.dijkstra(testStart,testEnd);
		List<GeographicPoint> testroute2 = simpleTestMap.aStarSearch(testStart,testEnd);
		
		
		MapGraph testMap = new MapGraph();
		GraphLoader.loadRoadMap("data/maps/utc.map", testMap);
		
		// A very simple test using real data
		testStart = new GeographicPoint(32.869423, -117.220917);
		testEnd = new GeographicPoint(32.869255, -117.216927);
		System.out.println("Test 2 using utc: Dijkstra should be 13 and AStar should be 5");
		testroute = testMap.dijkstra(testStart,testEnd);
		testroute2 = testMap.aStarSearch(testStart,testEnd);
		
		
		// A slightly more complex test using real data
		testStart = new GeographicPoint(32.8674388, -117.2190213);
		testEnd = new GeographicPoint(32.8697828, -117.2244506);
		System.out.println("Test 3 using utc: Dijkstra should be 37 and AStar should be 10");
		testroute = testMap.dijkstra(testStart,testEnd);
		testroute2 = testMap.aStarSearch(testStart,testEnd);
		*/
		
		
		/* Use this code in Week 3 End of Week Quiz */
		/*MapGraph theMap = new MapGraph();
		System.out.print("DONE. \nLoading the map...");
		GraphLoader.loadRoadMap("data/maps/utc.map", theMap);
		System.out.println("DONE.");

		GeographicPoint start = new GeographicPoint(32.8648772, -117.2254046);
		GeographicPoint end = new GeographicPoint(32.8660691, -117.217393);
		
		
		List<GeographicPoint> route = theMap.dijkstra(start,end);
		List<GeographicPoint> route2 = theMap.aStarSearch(start,end);

		*/
		
	}
	
}

class MapNode implements Comparable<MapNode>
{
	private GeographicPoint pt;
	private List<Edge> edges;
	private double actualDistance;

	public MapNode(GeographicPoint point)
	{
		this.pt=point;
		edges=new ArrayList<Edge>();
		this.actualDistance=0.0;
	}
	
	public void setActualDistance(double d)
	{
		this.actualDistance=d;
	}
	
	public void addEdge(GeographicPoint s,GeographicPoint e,String name,String type)
	{
		this.edges.add(new Edge(s,e,name,type));
	}
	
	public void addEdge(GeographicPoint s,GeographicPoint e,String name,String type,double d)
	{
		this.edges.add(new Edge(s,e,name,type,d));
	}
	
	public GeographicPoint getLocation()
	{
		return this.pt;
	}
	
	public List<Edge> getEdges()
	{
		return this.edges;
	}
	
	public double getDistance()
	{
		List<Double> ans=new ArrayList<Double>();
		if(this.edges.size()>0)
		{
			for(Edge e:this.edges)
			{
				ans.add(e.getDistance());
			}
		}
		
		Collections.sort(ans,Collections.reverseOrder());
		if(ans.size()>0)
			return ans.get(0);
		return Double.POSITIVE_INFINITY;
	}
	
	public double getActualDistance()
	{
		return this.actualDistance;
	}
	
	public int compareTo(MapNode m)
	{
		if(this.getActualDistance()>m.getActualDistance())
			return 1;
		if(this.getActualDistance()<m.getActualDistance())
			return -1;
		return 0;
	}
	
}



class Edge
{
	private GeographicPoint start;
	private GeographicPoint end;
	private String stName;
	private String type;
	private double distance;
	
	public Edge(GeographicPoint start,GeographicPoint end)
	{
		this.start=start;
		this.end=end;
	}
	
	public Edge(GeographicPoint start,GeographicPoint end,String st,String stType)
	{
		this.start=start;
		this.end=end;
		this.stName=st;
		this.type=stType;
	}
	
	public Edge(GeographicPoint start,GeographicPoint end,String st,String stType,double d)
	{
		this.start=start;
		this.end=end;
		this.stName=st;
		this.type=stType;
		this.distance=d;
	}
	
	public Edge(GeographicPoint start,GeographicPoint end,String st,double d)
	{
		this.start=start;
		this.end=end;
		this.stName=st;
		this.distance=d;
	}
	
	public GeographicPoint getEnd()
	{
		return this.end;
	}
	
	public double getDistance()
	{
		return this.distance;
	}
}
